Feature:Login functionality for Leaftaps application
#Background:
#Given Launch the browser and load the URL

Scenario:Login with valid credentials

When Enter the username 'democsr'
When Enter the password 'crmsfa'
And Click on LoginButton
Then Homepage is displayed

Scenario:Login with invalid credentials

When Enter the username 'demo'
When Enter the password 'crmsfa'
And Click on LoginButton
But Error msg is displayed