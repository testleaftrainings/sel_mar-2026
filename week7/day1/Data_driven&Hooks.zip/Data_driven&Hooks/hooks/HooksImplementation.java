package hooks;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import stepdefinition.PSM;

public class HooksImplementation extends PSM{
    

    @Before
    public void preConditions(){
        ChromeOptions options=new ChromeOptions();
    options.addArguments("guest");
     driver=new ChromeDriver(options);
    driver.get("https://leaftaps.com/opentaps/control/main");
    }
    @After
    public void postConditions(){
        driver.close();
    }

}
