package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import stepdefinition.PSM;
@CucumberOptions(features={"src/test/resources/features"},
    glue={"stepdefinition"},plugin={"pretty"}
)
public class RunnerCucumber extends PSM {

}
