package stepdefinition;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;




public class PSM extends AbstractTestNGCucumberTests {
    public static  ChromeDriver driver;
    @BeforeMethod
    public void preConditions(){
        ChromeOptions options=new ChromeOptions();
    options.addArguments("guest");
     driver=new ChromeDriver(options);
    driver.get("https://leaftaps.com/opentaps/control/main");
    }
    @AfterMethod
    public void postConditions(){
        driver.close();
    }


}
