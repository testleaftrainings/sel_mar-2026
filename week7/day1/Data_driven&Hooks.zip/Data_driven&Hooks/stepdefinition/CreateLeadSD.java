package stepdefinition;

import org.openqa.selenium.By;

import hooks.HooksImplementation;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadSD extends PSM{
    @When("Click on crmsfa Button")
public void click_on_crmsfa_button() {
    driver.findElement(By.linkText("CRM/SFA")).click();
    
}
@When("Click on LeadsLink")
public void click_on_leads_link() {
    driver.findElement(By.linkText("Leads")).click();
    
}
@When("CLICK ON create LeadsLink")
public void click_on_create_leads_link() {
    driver.findElement(By.linkText("Create Lead")).click();
    
}
@When("Enter the company name (.*)$")
public void enter_the_company_name(String cName) {
    driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
}
@When("Enter the firstName (.*)$")
public void enter_the_first_name(String fName) {
    driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
    
}
@When("Enter the lastName (.*)$")
public void enter_the_last_name(String lName) {
    driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
    
}
@When("Click on createSubmit Button")
public void click_on_create_submit_button() {
    driver.findElement(By.name("submitButton")).click();
    
}
@Then("lead is created successfully")
public void lead_is_created_successfully() {
    String text = driver.findElement(By.id("viewLead_firstName_sp")).getText();
    if (text.contains("Saranya")) {
        System.out.println("Lead is created");
    }else{
        System.out.println("lead is not created");
    }
    
}

}
