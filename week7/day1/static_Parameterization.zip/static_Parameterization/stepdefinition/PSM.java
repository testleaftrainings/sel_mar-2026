package stepdefinition;

import org.openqa.selenium.chrome.ChromeDriver;

public class PSM {
    public static  ChromeDriver driver;

}
