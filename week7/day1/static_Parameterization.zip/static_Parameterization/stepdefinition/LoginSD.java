package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSD extends PSM {
    
    @Given("Launch the browser and load the URL")
public void launch_the_browser_and_load_the_url() {
    ChromeOptions options=new ChromeOptions();
    options.addArguments("guest");
     driver=new ChromeDriver(options);
    driver.get("https://leaftaps.com/opentaps/control/main");
}
@When("Enter the username {string}")
public void enter_the_username(String uName) {
    driver.findElement(By.id("username")).sendKeys(uName);
    
}
@When("Enter the password {string}")
public void enter_the_password(String pwd) {
    driver.findElement(By.id("password")).sendKeys(pwd);
}
@When("Click on LoginButton")
public void click_on_login_button() {
    driver.findElement(By.className("decorativeSubmit")).click();
    
}

@Then("Homepage is displayed")
public void homepage_is_displayed() {
    String title = driver.getTitle();
    if (title.contains("Leaftaps")) {
        System.out.println("page is displayes");
    }else{
        System.out.println("page is not displayed");
    }
   
}
@When("Error msg is displayed")
public void error_msg_is_displayed() {
    String text = driver.findElement(By.id("errorDiv")).getText();
    if (text.contains("Errors")) {
        System.out.println("error msg is displayed");
    }else{
        System.out.println("error msg is not displayed");
    }
}

}
