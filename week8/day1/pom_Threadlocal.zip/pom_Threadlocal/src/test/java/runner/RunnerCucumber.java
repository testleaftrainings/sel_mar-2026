package runner;

import org.testng.annotations.DataProvider;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features={"src/test/resources/features"},
    glue={"pages"},plugin={"pretty"}
    

)
public class RunnerCucumber extends BaseClass {

    @DataProvider(parallel=true)
    public Object[][] scenarios(){
        return super.scenarios();
    }

}
