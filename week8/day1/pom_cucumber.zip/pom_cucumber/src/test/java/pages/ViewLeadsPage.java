package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends BaseClass {

    
    @Then("lead is created successfully")
    public ViewLeadsPage verifyLeads(){
        String text = driver.findElement(By.id("viewLead_firstName_sp")).getText();
    if (text.contains("Saranya")) {
        System.out.println("Lead is created");
    }else{
        System.out.println("lead is not created");
    }
    return this;
    }

    

}
