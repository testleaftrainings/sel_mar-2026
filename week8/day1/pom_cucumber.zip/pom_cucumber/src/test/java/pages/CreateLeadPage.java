package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {

    @When("Enter the company name (.*)$")
    public CreateLeadPage entercName(String uName){
        driver.findElement(By.id("createLeadForm_companyName")).sendKeys(uName);
        return this;
    }
    @When("Enter the firstName (.*)$")
    public CreateLeadPage enterfName(String fName){
        driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
        return this;
    }
    @When("Enter the lastName (.*)$")
    public CreateLeadPage enterlName(String lName){
    driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
    return this;
    }
    
    @And("Click on createSubmit Button")
    public ViewLeadsPage clickSubmit(){
        driver.findElement(By.name("submitButton")).click();
        return new ViewLeadsPage();
    }

}
