package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {

    

    @When("Enter the username {string}")
    public LoginPage enteruName(String uName){
        driver.findElement(By.id("username")).sendKeys(uName);
         return this;
    }
    @When("Enter the password {string}")
    public LoginPage enterpWord(String pwd){
        driver.findElement(By.id("password")).sendKeys(pwd);
        return this;
    }
    @And("Click on LoginButton")
    public WelcomePage clickLogin(){
        driver.findElement(By.className("decorativeSubmit")).click();
        return new WelcomePage();
    }


}
