Feature:CreateLead functionality for Leaftaps application
#Background:
#Given Launch the browser and load the URL

Scenario Outline:CreateLead with Multiple data
When Enter the username 'democsr'
When Enter the password 'crmsfa'
And Click on LoginButton
And Click on crmsfa Button
And Click on LeadsLink
And CLICK ON create LeadsLink
When Enter the company name <companyName>
When Enter the firstName <firstName>
When Enter the lastName <lastName>
And Click on createSubmit Button
Then lead is created successfully
Examples:
|companyName|firstName|lastName|
|infosys|Dharanidharan|D|
|TCS|Anitha|A|
|CTS|laxmidharan|L|



