package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_02 extends BaseClass {
    @Test
    public void runCreateLead(){

        //System.out.println("testclass:"+driver);

        LoginPage lp=new LoginPage(driver);
        lp.enteruName().enterpWord().clickLogin().clickCRMSFA().clickLeads()
        .clickCreateLead().entercName().enterfName().enterlName().clickSubmit().verifyLeads();

        

    }
}
