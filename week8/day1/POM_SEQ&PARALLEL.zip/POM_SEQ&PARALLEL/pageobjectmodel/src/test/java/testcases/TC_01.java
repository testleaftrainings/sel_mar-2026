package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;
import pages.WelcomePage;

public class TC_01 extends BaseClass{
    @Test
    public void runLogin(){

        System.out.println("testclass:"+driver);

        LoginPage lp=new LoginPage(driver);
        lp.enteruName().enterpWord().clickLogin();
        

    }

}
