package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {

    

    @When("Enter the username {string}")
    public LoginPage enteruName(String uName) throws IOException{
        try {
            getDriver().findElement(By.id("username")).sendKeys(uName);
            reportStep("uname entered sucessfully","pass");
        } catch (Exception e) {
            reportStep("uname not entered sucessfully","fail");
        }
        
         return this;
    }

    @When("Enter the password {string}")
    public LoginPage enterpWord(String pwd) throws IOException{
        try {
            getDriver().findElement(By.id("password")).sendKeys(pwd);
            reportStep("pwd entered sucessfully","pass");
        } catch (Exception e) {
            reportStep("pwd not entered sucessfully","fail");
        }
        
        return this;
    }
    @And("Click on LoginButton")
    public WelcomePage clickLogin(){
        try {
            getDriver().findElement(By.className("decorativeSubmit")).click();
            reportStep("Logged in sucessfully","pass");
        } catch (Exception e) {
        }
        
        return new WelcomePage();
    }


}
