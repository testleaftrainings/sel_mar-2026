package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass {
    @BeforeTest
    public void setValues(){
        excelFileName="Login";
        testName="Login for Leaftaps application";
        testDescription="Login with positive credentials";
        testAuthor="Saranya";
        testCategory="smoke";
    }
    @Test(dataProvider="fetchData")
    public void runLogin(String uName,String pwd) throws IOException{
        LoginPage lp=new LoginPage();
        lp.enteruName(uName).enterpWord(pwd).clickLogin();
    }

}
