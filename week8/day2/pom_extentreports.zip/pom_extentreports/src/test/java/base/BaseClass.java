package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

    //public static ChromeDriver driver;
    public static ExtentReports extent;
    public static ExtentTest test;
    public String testName,testDescription,testAuthor,testCategory,excelFileName;
    private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();

    @BeforeSuite
    public void startReports(){
         ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
        
         extent=new ExtentReports();
       
        extent.attachReporter(reporter);
    }
    @BeforeClass
    public void testCaseDetails(){
         test=extent.createTest(testName,testDescription);
          test.assignAuthor(testAuthor);
        test.assignCategory(testCategory);
    }
    public void setDriver(){
        ChromeOptions options=new ChromeOptions();
        options.addArguments("guest");
        cDriver.set(new ChromeDriver(options));//driver for eachThread
    }
    public ChromeDriver getDriver(){
        return cDriver.get();
    }
    @DataProvider(name="fetchData")
    public String[][] sendData() throws IOException{
        return ReadExcel.readData(excelFileName);
    }

    @BeforeMethod
    public void preConditions(){
    setDriver();//initialized the driver
     //driver=new ChromeDriver(options);
     //System.out.println("BeforeMethod:"+driver);
    getDriver().get("https://leaftaps.com/opentaps/control/main");
    getDriver().manage().window().maximize();
    getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    @AfterMethod
    public void postConditions(){
        getDriver().close();
    }

    public void reportStep(String msg,String status) throws IOException{
       if(status.equalsIgnoreCase("pass")){
        test.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+takeSnap()+".png").build());
       }else if(status.equalsIgnoreCase("fail")){
        test.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/img"+takeSnap()+".png").build());
        throw new RuntimeException("verify reports");
       }
    }
    public int takeSnap() throws IOException{
        int ranNum =(int)(Math.random() *999999 +999999);
        File src = getDriver().getScreenshotAs(OutputType.FILE);
        File destination=new File("./snap/img"+ranNum+".png");
        FileUtils.copyFile(src, destination);
        return ranNum;
        
    }
    @AfterSuite
    public void stopReports(){
        extent.flush();
    }


}
