package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

    public LoginPage enterUserName(String uName) {
		
		//clear & Type 
		//clearAndType(locateElement("username"), uName);
		clearAndType(locateElement("username"), uName);
		//clearAndType(locateElement(Locators.XPATH, "//input[@id='username']"), uName);
		reportStep("Entered  UserName is :"+uName, "pass");
		return this;
	}
	
	public LoginPage enterPassword(String pass) {
		//clear & Type 
		//clearAndType(locateElement("password"), pass);
		clearAndType(locateElement("password"), pass);
		reportStep("Entered PassWord is :"+pass, "pass");
		return this;
	}
	
	

	public void clickOnLogin() {
		click(locateElement(Locators.CLASS_NAME, "decorativeSubmit"));
		reportStep("Login is Clicked Successfully", "pass");
		
	}




}
