package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC001_VerifyLogin extends ProjectSpecificMethods{

    @BeforeTest
	public void setValues() {
		excelFileName="Login";
		testcaseName="LoginPage";
		testDescription="Login page";
		authors="Saranya";
		category="Regression";
	}
	
	
	@Test(dataProvider = "fetchData")
	public void runLoginTC(String uName,String passWord) {
		LoginPage user =new LoginPage();
		user.enterUserName(uName)
		    .enterPassword(passWord)
		    .clickOnLogin();
	}


}
